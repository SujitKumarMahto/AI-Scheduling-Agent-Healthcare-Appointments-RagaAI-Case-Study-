
# Reserved for future utilities (e.g., real SMTP/Twilio/Calendly integrations)
